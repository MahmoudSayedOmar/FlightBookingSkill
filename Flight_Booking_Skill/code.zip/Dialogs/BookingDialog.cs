﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AdaptiveCards;
using Flight_Booking_Skill.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Microsoft.Bot.Builder.Solutions.Extensions;
using Microsoft.Bot.Builder.Solutions.Responses;
using Flight_Booking_Skill.Utilities;
using Flight_Booking_Skill.Responses.Shared;

namespace Flight_Booking_Skill.Dialogs
{
    public class BookingDialog : SkillDialogBase
    {

        public BookingDialog(
            BotSettings settings,
            BotServices services,
            ResponseManager responseManager,
            ConversationState conversationState,
            IBotTelemetryClient telemetryClient)
           : base(nameof(BookingDialog), settings, services, responseManager, conversationState, telemetryClient)
        {

            // Restaurant Booking waterfall
            var bookingWaterfall = new WaterfallStep[]
            {
                Init
            };

            AddDialog(new WaterfallDialog(Actions.BookFlight, bookingWaterfall));

            // Prompts
            AddDialog(new ChoicePrompt(Actions.AskForDestination, ValidateDestination) { Style = ListStyle.Inline, ChoiceOptions = new ChoiceFactoryOptions { IncludeNumbers = true } });

            AddDialog(new DateTimePrompt(Actions.AskReservationDateStep, ValidateReservationDate));
            AddDialog(new DateTimePrompt(Actions.AskReservationTimeStep, ValidateReservationTime));
            AddDialog(new NumberPrompt<int>(Actions.AskAttendeeCountStep, ValidateAttendeeCount));
            AddDialog(new ConfirmPrompt(Actions.ConfirmSelectionBeforeBookingStep, ValidateBookingSelectionConfirmation));
            AddDialog(new ChoicePrompt(Actions.FlightPrompt, ValidateRestaurantSelection) { Style = ListStyle.Inline, ChoiceOptions = new ChoiceFactoryOptions { IncludeNumbers = true } });

            // Optional
            AddDialog(new ChoicePrompt(Actions.AmbiguousTimePrompt, ValidateAmbiguousTimePrompt) { Style = ListStyle.HeroCard, ChoiceOptions = new ChoiceFactoryOptions { IncludeNumbers = true } });

            // Set starting dialog for component
            InitialDialogId = Actions.BookFlight;


        }

        #region X

        private Task<bool> ValidateAmbiguousTimePrompt(PromptValidatorContext<FoundChoice> promptContext, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        private Task<bool> ValidateRestaurantSelection(PromptValidatorContext<FoundChoice> promptContext, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        private Task<bool> ValidateBookingSelectionConfirmation(PromptValidatorContext<bool> promptContext, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        private Task<bool> ValidateAttendeeCount(PromptValidatorContext<int> promptContext, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        private Task<bool> ValidateReservationTime(PromptValidatorContext<IList<DateTimeResolution>> promptContext, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        private Task<bool> ValidateReservationDate(PromptValidatorContext<IList<DateTimeResolution>> promptContext, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        private Task<bool> ValidateDestination(PromptValidatorContext<FoundChoice> promptContext, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        #endregion

        private async Task<DialogTurnResult> Init(WaterfallStepContext sc, CancellationToken cancellationToken = default(CancellationToken))
        {

            // This would be passed from the Virtual Assistant moving forward
            var tokens = new StringDictionary
            {
                { "UserName", null /*Name*/ ?? "Unknown" }
            };


            // Start the flow

            var reply = ResponseManager.GetResponse(FlightBookingSharedResponses.BookFlightFlowStartMessage, tokens);
            await sc.Context.SendActivityAsync(reply);

            return await sc.NextAsync(sc.Values, cancellationToken);
        }

    }
}
